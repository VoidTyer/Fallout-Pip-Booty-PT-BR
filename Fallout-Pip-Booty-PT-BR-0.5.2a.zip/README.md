PT-BR Translation Gemini Pro
